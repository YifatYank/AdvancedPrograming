//
// Created by yifat on 01/12/16.
//

#ifndef UNITTEST_ENUMS_H
#define UNITTEST_ENUMS_H

enum Marital_Status {
    single,married,divorced,widowed
};

enum Manufacturer {
    HONDA, SUBARO, TESLA,FIAT
};

enum Color{
    RED,BLUE,GREEN,PINK,WHITE
};

#endif //UNITTEST_ENUMS_H
